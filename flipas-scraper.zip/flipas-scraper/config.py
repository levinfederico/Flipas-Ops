"""
FLIPAS REAL ESTATE — Configuración del agente scraper
Todos los parámetros de búsqueda y filtrado centralizados acá.
"""

# ── PORTALES ──────────────────────────────────────────────────────────────
PORTALS = {
    "mercadolibre": True,
    "zonaprop":     True,
    "argenprop":    True,
    "remax":        True,
}

# ── BARRIOS ───────────────────────────────────────────────────────────────
TARGET_BARRIOS = [
    "Saavedra", "Núñez", "Nuñez", "Coghlan",
    "Belgrano", "Belgrano R", "Belgrano C", "Barrio Chino",
    "Colegiales", "Palermo", "Palermo Hollywood", "Palermo Soho",
    "Las Cañitas", "Las Canitas",
]

# ── TIPOLOGÍAS ────────────────────────────────────────────────────────────
PROPERTY_TYPES = ["PH", "Departamento"]

# ── REGLAS POR TIPO ───────────────────────────────────────────────────────
PH_RULES = {
    "requires_outdoor": True,          # patio y/o terraza obligatorio
    "outdoor_keywords": ["patio", "terraza", "deck", "azotea", "parrilla"],
    "allow_pb": True,                  # PH en PB: permitido
}

DEPTO_RULES = {
    "exclude_pb": True,                # No planta baja
    "exclude_interior": True,          # No interno
    "allowed_orientations": ["frente", "contrafrente", "lateral"],
}

# ── COCHERA ───────────────────────────────────────────────────────────────
COCHERA_VALUE = {
    "PH":          20_000,   # USD a restar del precio
    "Departamento": 25_000,  # USD a restar del precio
}

# ── PONDERACIÓN M² ────────────────────────────────────────────────────────
M2_WEIGHT = {
    "cubierto":      1.00,
    "semicubierto":  0.50,
    "descubierto":   0.33,
}

# ── UMBRALES USD/m² PONDERADO ─────────────────────────────────────────────
THRESHOLDS = {
    "urgente":    1_300,   # < 1300  → Atacar urgente 🔴
    "oportunidad": 1_400,  # 1300–1400 → Oportunidad 🟠
    "negociable":  1_500,  # 1400–1500 → Negociable 🟡
    # > 1500 → No reportar
}

# ── SUPERFICIE MÍNIMA ─────────────────────────────────────────────────────
MIN_M2_TOTAL = 50          # m² totales mínimos

# ── AMBIENTES ─────────────────────────────────────────────────────────────
MIN_AMBIENTES = 2
MAX_AMBIENTES = 5

# ── FRECUENCIA DE SCRAPING ────────────────────────────────────────────────
SCRAPE_INTERVAL_HOURS = 2

# ── NOTIFICACIONES ────────────────────────────────────────────────────────
NOTIFICATION_CONFIG = {
    # Email
    "email_enabled":   True,
    "smtp_host":       "smtp.gmail.com",
    "smtp_port":       587,
    "email_from":      "flipasre@gmail.com",
    "email_to":        ["flipasre@gmail.com"],  # agregar más si necesario
    # Telegram (recomendado para push instantáneo)
    "telegram_enabled": True,
    "telegram_bot_token": "",   # completar con tu bot token
    "telegram_chat_id":   "",   # completar con tu chat ID
    # Alertas solo cuando hay oportunidades nuevas
    "notify_only_new": True,
    "alert_levels":    ["urgente", "oportunidad", "negociable"],
}

# ── GOOGLE SHEETS ─────────────────────────────────────────────────────────
SHEETS_CONFIG = {
    "enabled":         True,
    "spreadsheet_id":  "",    # ID del Google Sheet de destino
    "credentials_file": "credentials.json",
    "sheet_name":      "Oportunidades",
}

# ── PATHS ─────────────────────────────────────────────────────────────────
DATA_JSON_PATH = "data.json"
SEEN_IDS_PATH  = "seen_ids.json"   # IDs ya vistos (para detectar nuevos)
