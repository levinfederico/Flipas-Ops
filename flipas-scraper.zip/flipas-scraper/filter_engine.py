"""
FLIPAS — Motor de filtrado y scoring
Aplica todas las reglas de negocio a cada propiedad cruda.
"""

from config import (
    TARGET_BARRIOS, PH_RULES, DEPTO_RULES,
    COCHERA_VALUE, M2_WEIGHT, THRESHOLDS,
    MIN_M2_TOTAL, MIN_AMBIENTES, MAX_AMBIENTES,
)


def normalize_barrio(barrio: str) -> str:
    """Normaliza nombre de barrio para comparación."""
    replacements = {
        "nuñez": "Núñez", "nunez": "Núñez",
        "las canitas": "Las Cañitas", "las cañitas": "Las Cañitas",
        "palermo hollywood": "Palermo Hollywood",
        "palermo soho": "Palermo Soho",
        "belgrano r": "Belgrano R", "belgrano c": "Belgrano C",
    }
    return replacements.get(barrio.lower().strip(), barrio.strip())


def is_target_barrio(barrio: str) -> bool:
    normalized = normalize_barrio(barrio)
    return any(
        normalized.lower() in t.lower() or t.lower() in normalized.lower()
        for t in TARGET_BARRIOS
    )


def calc_weighted_m2(m2_cub: float, m2_semi: float, m2_desc: float) -> float:
    """Calcula m² ponderados según metodología Flipas."""
    return (
        m2_cub  * M2_WEIGHT["cubierto"] +
        m2_semi * M2_WEIGHT["semicubierto"] +
        m2_desc * M2_WEIGHT["descubierto"]
    )


def calc_effective_price(price_usd: float, prop_type: str, has_cochera: bool) -> float:
    """Resta el valor de cochera si aplica."""
    if has_cochera and prop_type in COCHERA_VALUE:
        return max(0, price_usd - COCHERA_VALUE[prop_type])
    return price_usd


def calc_usd_per_m2(effective_price: float, weighted_m2: float) -> float | None:
    """Calcula USD/m² ponderado. Retorna None si no se puede calcular."""
    if weighted_m2 <= 0:
        return None
    return effective_price / weighted_m2


def get_alert_level(usd_m2: float) -> str | None:
    """
    Clasifica el USD/m² en nivel de alerta.
    None = fuera de rango (no reportar)
    """
    if usd_m2 < THRESHOLDS["urgente"]:
        return "urgente"
    elif usd_m2 < THRESHOLDS["oportunidad"]:
        return "oportunidad"
    elif usd_m2 < THRESHOLDS["negociable"]:
        return "negociable"
    return None


def check_ph_rules(prop: dict) -> tuple[bool, str]:
    """
    Verifica reglas específicas para PHs.
    Retorna (pasa, motivo_rechazo)
    """
    if not PH_RULES["requires_outdoor"]:
        return True, ""

    description = (prop.get("description", "") + " " +
                   prop.get("features_raw", "")).lower()
    title = prop.get("title", "").lower()
    combined = description + " " + title

    has_outdoor = any(
        kw in combined
        for kw in PH_RULES["outdoor_keywords"]
    )
    # También chequear campos explícitos
    if prop.get("has_patio") or prop.get("has_terraza") or prop.get("has_deck"):
        has_outdoor = True

    if not has_outdoor:
        return False, "PH sin patio/terraza"
    return True, ""


def check_depto_rules(prop: dict) -> tuple[bool, str]:
    """
    Verifica reglas específicas para departamentos.
    Retorna (pasa, motivo_rechazo)
    """
    if DEPTO_RULES["exclude_pb"]:
        floor = prop.get("floor")
        if floor is not None and floor == 0:
            return False, "Planta baja excluida para deptos"
        # Detectar PB en descripción
        title_desc = (prop.get("title", "") + " " +
                      prop.get("description", "")).lower()
        pb_keywords = ["planta baja", "pb ", " pb,", "piso 0"]
        if any(kw in title_desc for kw in pb_keywords):
            return False, "Planta baja excluida para deptos"

    if DEPTO_RULES["exclude_interior"]:
        title_desc = (prop.get("title", "") + " " +
                      prop.get("description", "")).lower()
        interior_kw = [" interno", " interior", "contrafrente interno"]
        # "contrafrente" sin "interno" es OK
        if any(kw in title_desc for kw in interior_kw):
            return False, "Departamento interior excluido"

    return True, ""


def filter_property(prop: dict) -> dict | None:
    """
    Aplica todas las reglas de negocio a una propiedad cruda.
    Retorna la propiedad enriquecida con score/alert_level,
    o None si no pasa los filtros.
    """
    # 1. Barrio
    if not is_target_barrio(prop.get("barrio", "")):
        return None

    # 2. Tipo de propiedad
    prop_type = prop.get("type", "")
    if prop_type not in ["PH", "Departamento"]:
        return None

    # 3. Ambientes
    amb = prop.get("ambientes")
    if amb is not None:
        if amb < MIN_AMBIENTES or amb > MAX_AMBIENTES:
            return None

    # 4. Reglas por tipo
    if prop_type == "PH":
        ok, reason = check_ph_rules(prop)
        if not ok:
            return None
    elif prop_type == "Departamento":
        ok, reason = check_depto_rules(prop)
        if not ok:
            return None

    # 5. Calcular m²
    m2_cub  = float(prop.get("m2_covered",  0) or 0)
    m2_semi = float(prop.get("m2_semi",     0) or 0)
    m2_desc = float(prop.get("m2_uncovered",0) or 0)
    m2_tot  = float(prop.get("m2_total",    0) or 0)

    # Si no hay total, estimarlo
    if m2_tot == 0:
        m2_tot = m2_cub + m2_semi + m2_desc
    # Si no hay desglose pero hay total, asumir todo cubierto
    if m2_cub == 0 and m2_tot > 0:
        m2_cub = m2_tot

    if m2_tot < MIN_M2_TOTAL:
        return None

    weighted = calc_weighted_m2(m2_cub, m2_semi, m2_desc)
    if weighted == 0:
        weighted = m2_tot  # fallback

    # 6. Precio
    price = float(prop.get("price_usd", 0) or 0)
    if price <= 0:
        return None

    has_cochera = bool(prop.get("has_cochera", False))
    eff_price = calc_effective_price(price, prop_type, has_cochera)

    usd_m2 = calc_usd_per_m2(eff_price, weighted)
    if usd_m2 is None:
        return None

    # 7. Nivel de alerta
    alert_level = get_alert_level(usd_m2)
    if alert_level is None:
        return None  # Fuera de rango, no reportar

    # 8. Score (0-100)
    score = calc_score(prop, usd_m2, alert_level)

    return {
        **prop,
        "m2_covered":   m2_cub,
        "m2_semi":      m2_semi,
        "m2_uncovered": m2_desc,
        "m2_total":     m2_tot,
        "m2_weighted":  round(weighted, 1),
        "effective_price": eff_price,
        "usd_per_m2":   round(usd_m2, 0),
        "alert_level":  alert_level,
        "score":        score,
    }


def calc_score(prop: dict, usd_m2: float, alert_level: str) -> int:
    """Score de 0–100 para rankear oportunidades."""
    score = 0

    # USD/m² (max 35 pts)
    if usd_m2 < 1000:    score += 35
    elif usd_m2 < 1100:  score += 28
    elif usd_m2 < 1200:  score += 20
    elif usd_m2 < 1300:  score += 14
    elif usd_m2 < 1400:  score += 8
    else:                score += 3

    # Barrio (max 20 pts)
    barrio = prop.get("barrio", "").lower()
    tier1 = ["palermo", "colegiales", "belgrano r", "belgrano c", "las cañitas"]
    tier2 = ["núñez", "nuñez", "belgrano", "coghlan"]
    if any(t in barrio for t in tier1):  score += 20
    elif any(t in barrio for t in tier2): score += 12
    else:                                  score += 5

    # Tipo (max 15 pts)
    has_outdoor = (prop.get("has_patio") or prop.get("has_terraza")
                   or prop.get("has_deck"))
    if prop.get("type") == "PH" and has_outdoor: score += 15
    elif prop.get("type") == "PH":                score += 8
    else:                                          score += 5

    # Recencia (max 15 pts)
    if prop.get("is_new"):        score += 15
    elif prop.get("hours_ago", 999) < 24: score += 10
    elif prop.get("hours_ago", 999) < 48: score += 5

    # Señales extra (max 15 pts)
    desc = (prop.get("description", "") + " " + prop.get("title", "")).lower()
    if "urgente" in desc or "oportunidad" in desc:   score += 5
    if "sin expensas" in desc or "0 expensas" in desc: score += 4
    if prop.get("has_cochera"):                        score += 3
    if "sucesión" in desc or "herederos" in desc:      score += 3

    return min(100, score)
