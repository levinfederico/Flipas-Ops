"""
FLIPAS — Sistema de notificaciones
Email SMTP + Telegram para alertas instantáneas.
"""

import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

import requests

from config import NOTIFICATION_CONFIG, THRESHOLDS

ALERT_EMOJI = {
    "urgente":    "🔴",
    "oportunidad":"🟠",
    "negociable": "🟡",
}

ALERT_LABEL = {
    "urgente":    "ATACAR URGENTE",
    "oportunidad":"OPORTUNIDAD",
    "negociable": "NEGOCIABLE",
}


def format_property_text(prop: dict) -> str:
    """Formatea una propiedad para notificación."""
    emoji = ALERT_EMOJI.get(prop["alert_level"], "⚪")
    label = ALERT_LABEL.get(prop["alert_level"], "")
    new_tag = "🆕 NUEVA · " if prop.get("is_new") else ""

    cochera = "🚗 Con cochera" if prop.get("has_cochera") else ""
    outdoor = []
    if prop.get("has_patio"):   outdoor.append("patio")
    if prop.get("has_terraza"): outdoor.append("terraza")
    if prop.get("has_balcon"):  outdoor.append("balcón")
    outdoor_str = " · ".join(outdoor) if outdoor else ""

    m2_info = f"{prop.get('m2_covered',0):.0f}m² cub"
    if prop.get("m2_uncovered", 0) > 0:
        m2_info += f" + {prop.get('m2_uncovered',0):.0f}m² desc"
    m2_info += f" = {prop.get('m2_total',0):.0f}m² tot"

    return (
        f"{emoji} {new_tag}{label}\n"
        f"📍 {prop.get('barrio')} · {prop.get('type')}\n"
        f"🏠 {prop.get('address') or prop.get('title', '')}\n"
        f"📐 {m2_info} ({prop.get('m2_weighted',0):.0f}m² pond.)\n"
        f"💰 USD {prop.get('price_usd',0):,.0f}"
        f" → USD/m² ponderado: {prop.get('usd_per_m2',0):,.0f}\n"
        f"📊 Score: {prop.get('score', 0)}/100 · {prop.get('source')}\n"
        + (f"🚗 Cochera incluida\n" if prop.get("has_cochera") else "")
        + (f"🌿 {outdoor_str}\n" if outdoor_str else "")
        + f"🔗 {prop.get('url', '')}"
    )


# ── EMAIL ──────────────────────────────────────────────────────────────────

def build_email_html(properties: list[dict]) -> str:
    """Construye el HTML del email de alerta."""
    rows = ""
    for prop in properties:
        emoji = ALERT_EMOJI.get(prop["alert_level"], "⚪")
        label = ALERT_LABEL.get(prop["alert_level"], "")
        bg = {"urgente": "#FFEBEE", "oportunidad": "#FFF8E1", "negociable": "#F3F8FF"}.get(
            prop["alert_level"], "#fff"
        )
        new_badge = '<span style="background:#1565C0;color:#fff;font-size:10px;padding:2px 6px;border-radius:10px;margin-left:6px">NUEVA</span>' if prop.get("is_new") else ""
        rows += f"""
        <tr style="background:{bg}">
          <td style="padding:10px 12px;font-size:15px">{emoji}</td>
          <td style="padding:10px 12px">
            <strong>{label}</strong>{new_badge}<br>
            <span style="color:#555;font-size:13px">{prop.get('barrio')} · {prop.get('type')}</span><br>
            <span style="font-size:12px;color:#777">{prop.get('address') or prop.get('title','')[:60]}</span>
          </td>
          <td style="padding:10px 12px;text-align:right">
            <strong>USD {prop.get('price_usd',0):,.0f}</strong><br>
            <span style="color:#C62828;font-weight:700;font-size:13px">
              USD {prop.get('usd_per_m2',0):,.0f}/m² pond.
            </span>
          </td>
          <td style="padding:10px 12px;text-align:center;font-size:12px;color:#555">
            {prop.get('m2_total',0):.0f}m²<br>
            Score: {prop.get('score',0)}/100
          </td>
          <td style="padding:10px 12px">
            <a href="{prop.get('url','')}" style="background:#263238;color:#fff;padding:6px 12px;border-radius:4px;text-decoration:none;font-size:12px">
              Ver aviso
            </a>
          </td>
        </tr>"""

    urgente_count = sum(1 for p in properties if p["alert_level"] == "urgente")

    return f"""
    <html><body style="font-family:Arial,sans-serif;max-width:700px;margin:0 auto">
      <div style="background:#263238;padding:16px 20px;border-radius:6px 6px 0 0">
        <span style="color:#D4AF37;font-size:18px;font-weight:700">FLIPAS</span>
        <span style="color:#90A4AE;font-size:11px;margin-left:8px">REAL ESTATE</span>
        <span style="color:#fff;float:right;font-size:14px">
          {len(properties)} oportunidad{'es' if len(properties)>1 else ''} detectada{'s' if len(properties)>1 else ''}
          {f'— {urgente_count} 🔴 URGENTE' if urgente_count else ''}
        </span>
      </div>
      <table style="width:100%;border-collapse:collapse;border:1px solid #ECEFF1">
        <thead>
          <tr style="background:#607D8B;color:#fff">
            <th style="padding:8px 12px;text-align:left"></th>
            <th style="padding:8px 12px;text-align:left">Propiedad</th>
            <th style="padding:8px 12px;text-align:right">Precio</th>
            <th style="padding:8px 12px;text-align:center">M²</th>
            <th style="padding:8px 12px">Link</th>
          </tr>
        </thead>
        <tbody>{rows}</tbody>
      </table>
      <div style="background:#F6F8FA;padding:10px 16px;font-size:11px;color:#90A4AE;text-align:center;border-radius:0 0 6px 6px">
        Flipas Real Estate · {datetime.now().strftime('%d/%m/%Y %H:%M')} ·
        Precio/m² calculado sobre m² ponderados (cubiertos + semi×0.5 + descubiertos×0.33).
        Cochera deducida del precio antes del cálculo.
      </div>
    </html></body>"""


def send_email(properties: list[dict]) -> bool:
    """Envía email de alerta via SMTP."""
    cfg = NOTIFICATION_CONFIG
    if not cfg.get("email_enabled") or not properties:
        return False

    smtp_pass = os.environ.get("SMTP_PASSWORD", "")
    if not smtp_pass:
        print("[EMAIL] No hay SMTP_PASSWORD configurada")
        return False

    urgente = [p for p in properties if p["alert_level"] == "urgente"]
    subject = (
        f"🔴 FLIPAS: {len(urgente)} oportunidad(es) URGENTE — {len(properties)} total"
        if urgente else
        f"🟠 FLIPAS: {len(properties)} oportunidad(es) detectada(s)"
    )

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = cfg["email_from"]
    msg["To"]      = ", ".join(cfg["email_to"])

    html = build_email_html(properties)
    msg.attach(MIMEText(html, "html"))

    try:
        with smtplib.SMTP(cfg["smtp_host"], cfg["smtp_port"]) as server:
            server.starttls()
            server.login(cfg["email_from"], smtp_pass)
            server.sendmail(cfg["email_from"], cfg["email_to"], msg.as_string())
        print(f"[EMAIL] Enviado a {cfg['email_to']}: {len(properties)} oportunidades")
        return True
    except Exception as e:
        print(f"[EMAIL] Error: {e}")
        return False


# ── TELEGRAM ───────────────────────────────────────────────────────────────

def send_telegram(properties: list[dict]) -> bool:
    """Envía alerta via Telegram Bot."""
    cfg = NOTIFICATION_CONFIG
    if not cfg.get("telegram_enabled") or not properties:
        return False

    token   = os.environ.get("TELEGRAM_BOT_TOKEN", cfg.get("telegram_bot_token", ""))
    chat_id = os.environ.get("TELEGRAM_CHAT_ID", cfg.get("telegram_chat_id", ""))

    if not token or not chat_id:
        print("[TELEGRAM] Token o chat_id no configurados")
        return False

    # Agrupar por nivel de alerta
    for level in ["urgente", "oportunidad", "negociable"]:
        props_level = [p for p in properties if p["alert_level"] == level]
        if not props_level:
            continue

        # Enviar máximo 5 por nivel para no saturar
        for prop in props_level[:5]:
            text = format_property_text(prop)
            try:
                resp = requests.post(
                    f"https://api.telegram.org/bot{token}/sendMessage",
                    json={
                        "chat_id":    chat_id,
                        "text":       text,
                        "parse_mode": "HTML",
                        "disable_web_page_preview": False,
                    },
                    timeout=10,
                )
                if not resp.ok:
                    print(f"[TELEGRAM] Error: {resp.text}")
                time.sleep(0.5)
            except Exception as e:
                print(f"[TELEGRAM] Error: {e}")

    print(f"[TELEGRAM] Enviadas {len(properties)} alertas")
    return True


def notify_new_opportunities(new_props: list[dict]) -> None:
    """Dispara todas las notificaciones para oportunidades nuevas."""
    if not new_props:
        print("[NOTIFY] Sin oportunidades nuevas para notificar")
        return

    # Ordenar: urgente primero, luego por score
    sorted_props = sorted(
        new_props,
        key=lambda x: (
            {"urgente": 0, "oportunidad": 1, "negociable": 2}.get(x["alert_level"], 3),
            -x.get("score", 0)
        )
    )

    print(f"[NOTIFY] Enviando alertas para {len(sorted_props)} oportunidades nuevas")
    send_email(sorted_props)
    send_telegram(sorted_props)
