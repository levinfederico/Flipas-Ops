"""
FLIPAS — Scraper de MercadoLibre Inmuebles
Usa la API pública oficial de ML (sin autenticación necesaria).
Es la fuente más confiable y rápida de detectar oportunidades nuevas.
"""

import requests
import time
from datetime import datetime, timezone
from config import TARGET_BARRIOS, MIN_AMBIENTES, MAX_AMBIENTES

# API de MercadoLibre — Inmuebles CABA
ML_BASE = "https://api.mercadolibre.com"

# Categorías de ML para inmuebles
ML_CATEGORIES = {
    "PH":           "MLA1472",   # PH y casas
    "Departamento": "MLA1473",   # Departamentos
}

# Mapeo de barrios ML → nombres internos
BARRIO_MAP = {
    "saavedra":           "Saavedra",
    "núñez":              "Núñez",
    "nuñez":              "Núñez",
    "coghlan":            "Coghlan",
    "belgrano":           "Belgrano",
    "colegiales":         "Colegiales",
    "palermo":            "Palermo",
    "palermo hollywood":  "Palermo Hollywood",
    "palermo soho":       "Palermo Soho",
    "las cañitas":        "Las Cañitas",
    "las canitas":        "Las Cañitas",
    "belgrano r":         "Belgrano R",
    "belgrano c":         "Belgrano C",
}

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; FlipasBot/1.0)",
    "Accept": "application/json",
}


def get_ml_listings(prop_type: str = "PH", limit: int = 50, offset: int = 0) -> list[dict]:
    """Busca propiedades en ML usando la API oficial."""
    category = ML_CATEGORIES.get(prop_type, ML_CATEGORIES["PH"])

    params = {
        "category": category,
        "state":    "TUxBUENBUGw3M2JR",  # Buenos Aires province
        "city":     "TUxBQ0NBUGZlZG1l",  # CABA
        "sort":     "date_desc",           # Más recientes primero
        "limit":    limit,
        "offset":   offset,
    }

    try:
        resp = requests.get(
            f"{ML_BASE}/sites/MLA/search",
            params=params,
            headers=HEADERS,
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
        return data.get("results", [])
    except Exception as e:
        print(f"[ML] Error fetching {prop_type}: {e}")
        return []


def get_ml_item_detail(item_id: str) -> dict:
    """Obtiene detalles adicionales de un ítem de ML."""
    try:
        resp = requests.get(
            f"{ML_BASE}/items/{item_id}",
            headers=HEADERS,
            timeout=10,
        )
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"[ML] Error getting detail for {item_id}: {e}")
        return {}


def extract_attribute(attributes: list, id_name: str) -> str | None:
    """Extrae valor de un atributo de ML por ID."""
    for attr in attributes:
        if attr.get("id") == id_name:
            return attr.get("value_name") or attr.get("value_struct", {}).get("number")
    return None


def parse_ml_item(item: dict, prop_type: str) -> dict:
    """Convierte un ítem crudo de ML al formato interno de Flipas."""
    attrs = item.get("attributes", [])

    # Barrio
    location = item.get("location", {})
    neighborhood = location.get("neighborhood", {}).get("name", "")
    city_area = location.get("city_subdivision", {}).get("name", "")
    barrio_raw = neighborhood or city_area or ""
    barrio = BARRIO_MAP.get(barrio_raw.lower(), barrio_raw)

    # M²
    def safe_float(v):
        try: return float(v) if v else 0.0
        except: return 0.0

    m2_cub  = safe_float(extract_attribute(attrs, "COVERED_AREA"))
    m2_tot  = safe_float(extract_attribute(attrs, "TOTAL_AREA"))
    m2_semi = safe_float(extract_attribute(attrs, "SEMI_COVERED_AREA"))
    m2_desc = max(0.0, m2_tot - m2_cub - m2_semi)

    # Ambientes
    rooms_raw = extract_attribute(attrs, "ROOMS")
    try:
        ambientes = int(rooms_raw) if rooms_raw else None
    except:
        ambientes = None

    # Precio
    price = item.get("price", 0) or 0
    currency = item.get("currency_id", "USD")
    if currency != "USD":
        price = 0  # Solo USD

    # Cochera
    garage = extract_attribute(attrs, "PARKING_LOTS")
    has_cochera = bool(garage and int(garage) > 0 if garage else False)

    # Outdoor detectado en título/descripción
    title = item.get("title", "")
    desc = " ".join(
        tag.get("name", "") for tag in item.get("tags", [])
    )
    combined = (title + " " + desc).lower()
    has_patio   = "patio" in combined
    has_terraza = "terraza" in combined
    has_balcon  = "balcón" in combined or "balcon" in combined

    # Recencia
    date_str = item.get("date_created", "")
    is_new = False
    hours_ago = 9999
    if date_str:
        try:
            pub_date = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
            delta = datetime.now(timezone.utc) - pub_date
            hours_ago = delta.total_seconds() / 3600
            is_new = hours_ago < 48
        except:
            pass

    # Thumbnail
    thumbnail = item.get("thumbnail", "")

    return {
        "id":           f"ML-{item.get('id', '')}",
        "source":       "MercadoLibre",
        "type":         prop_type,
        "barrio":       barrio,
        "address":      location.get("address_line", ""),
        "title":        title,
        "description":  "",  # Se puede obtener con get_ml_item_detail
        "m2_covered":   m2_cub,
        "m2_semi":      m2_semi,
        "m2_uncovered": m2_desc,
        "m2_total":     m2_tot,
        "ambientes":    ambientes,
        "price_usd":    price,
        "has_cochera":  has_cochera,
        "has_patio":    has_patio,
        "has_terraza":  has_terraza,
        "has_balcon":   has_balcon,
        "expensas_ars": 0,
        "floor":        None,
        "url":          item.get("permalink", ""),
        "image_url":    thumbnail,
        "date_created": date_str,
        "is_new":       is_new,
        "hours_ago":    round(hours_ago, 1),
        "features_raw": desc,
    }


def scrape_mercadolibre() -> list[dict]:
    """
    Scrapea ML para PHs y Departamentos.
    Retorna lista de propiedades en formato interno Flipas.
    """
    print("[ML] Iniciando scraping...")
    results = []
    seen = set()

    for prop_type in ["PH", "Departamento"]:
        for offset in range(0, 200, 50):  # Hasta 200 resultados por tipo
            items = get_ml_listings(prop_type, limit=50, offset=offset)
            if not items:
                break

            for item in items:
                item_id = item.get("id")
                if item_id in seen:
                    continue
                seen.add(item_id)

                parsed = parse_ml_item(item, prop_type)
                results.append(parsed)

            time.sleep(0.5)  # Respetar rate limits

        print(f"[ML] {prop_type}: {len([r for r in results if r['type']==prop_type])} encontrados")

    print(f"[ML] Total: {len(results)} propiedades")
    return results
