"""
FLIPAS — Scrapers de ZonaProp y Argenprop
Usan requests + BeautifulSoup para parsear los resultados.
Nota: estos portales tienen Cloudflare. Si hay bloqueos, usar
cloudscraper en lugar de requests.
"""

import time
import re
import json
from datetime import datetime, timezone

try:
    import cloudscraper
    _scraper = cloudscraper.create_scraper()
    def get(url, **kwargs): return _scraper.get(url, **kwargs)
except ImportError:
    import requests
    def get(url, **kwargs): return requests.get(url, **kwargs)

from bs4 import BeautifulSoup


HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "es-AR,es;q=0.9",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

# ══════════════════════════════════════════════
# ZONAPROP
# ══════════════════════════════════════════════

ZP_BARRIOS = [
    "saavedra", "nunez", "coghlan", "belgrano", "colegiales",
    "palermo-hollywood", "palermo-soho", "palermo", "las-canitas",
    "belgrano-r", "belgrano-c",
]

ZP_BARRIO_MAP = {
    "saavedra": "Saavedra",
    "nunez": "Núñez",
    "coghlan": "Coghlan",
    "belgrano": "Belgrano",
    "colegiales": "Colegiales",
    "palermo-hollywood": "Palermo Hollywood",
    "palermo-soho": "Palermo Soho",
    "palermo": "Palermo",
    "las-canitas": "Las Cañitas",
    "belgrano-r": "Belgrano R",
    "belgrano-c": "Belgrano C",
}


def scrape_zonaprop_page(url: str, barrio: str, prop_type: str) -> list[dict]:
    """Scrapea una página de resultados de ZonaProp."""
    try:
        resp = get(url, headers=HEADERS, timeout=15)
        resp.raise_for_status()
    except Exception as e:
        print(f"[ZP] Error {url}: {e}")
        return []

    soup = BeautifulSoup(resp.text, "html.parser")
    results = []

    # ZonaProp guarda los datos en un script __NEXT_DATA__
    script = soup.find("script", {"id": "__NEXT_DATA__"})
    if script:
        try:
            data = json.loads(script.string)
            props = (data.get("props", {})
                        .get("pageProps", {})
                        .get("searchResult", {})
                        .get("listings", []))
            for p in props:
                parsed = parse_zp_listing(p, barrio, prop_type)
                if parsed:
                    results.append(parsed)
            return results
        except Exception as e:
            print(f"[ZP] JSON parse error: {e}")

    # Fallback: parseo HTML directo
    listings = soup.select("[data-id]")
    for listing in listings:
        parsed = parse_zp_html(listing, barrio, prop_type)
        if parsed:
            results.append(parsed)

    return results


def parse_zp_listing(data: dict, barrio: str, prop_type: str) -> dict | None:
    """Parsea un listing del JSON de ZonaProp."""
    try:
        listing = data.get("listing", data)
        price_obj = listing.get("priceOperationTypes", [{}])[0]
        price = float(price_obj.get("prices", [{}])[0].get("amount", 0) or 0)
        currency = price_obj.get("prices", [{}])[0].get("currency", "USD")
        if currency != "USD":
            return None

        surfaces = listing.get("totalSurface", 0) or 0
        covered  = listing.get("roofedSurface", 0) or 0
        semi     = listing.get("semiRoofedSurface", 0) or 0
        uncover  = max(0, surfaces - covered - semi)

        rooms = listing.get("rooms", None)
        title = listing.get("title", "")
        desc  = listing.get("description", "")
        combined = (title + " " + desc).lower()

        has_cochera = "cochera" in combined or "garage" in combined
        has_patio   = "patio" in combined
        has_terraza = "terraza" in combined
        has_balcon  = "balcón" in combined or "balcon" in combined

        # URL
        permalink = listing.get("permalink", "")
        if permalink and not permalink.startswith("http"):
            permalink = f"https://www.zonaprop.com.ar{permalink}"

        pub_date_str = listing.get("publicationDate", "")
        is_new = False
        hours_ago = 9999
        if pub_date_str:
            try:
                pub_date = datetime.fromisoformat(pub_date_str.replace("Z", "+00:00"))
                delta = datetime.now(timezone.utc) - pub_date
                hours_ago = delta.total_seconds() / 3600
                is_new = hours_ago < 48
            except:
                pass

        return {
            "id":           f"ZP-{listing.get('globalId', listing.get('id', ''))}",
            "source":       "Zonaprop",
            "type":         prop_type,
            "barrio":       ZP_BARRIO_MAP.get(barrio, barrio),
            "address":      listing.get("address", ""),
            "title":        title,
            "description":  desc[:500],
            "m2_covered":   float(covered or 0),
            "m2_semi":      float(semi or 0),
            "m2_uncovered": float(uncover),
            "m2_total":     float(surfaces or 0),
            "ambientes":    int(rooms) if rooms else None,
            "price_usd":    price,
            "has_cochera":  has_cochera,
            "has_patio":    has_patio,
            "has_terraza":  has_terraza,
            "has_balcon":   has_balcon,
            "expensas_ars": float(listing.get("expenses", 0) or 0),
            "floor":        listing.get("floor"),
            "url":          permalink,
            "image_url":    listing.get("photos", [{}])[0].get("image360", {}).get("url", ""),
            "date_created": pub_date_str,
            "is_new":       is_new,
            "hours_ago":    round(hours_ago, 1),
            "features_raw": combined,
        }
    except Exception as e:
        print(f"[ZP] parse error: {e}")
        return None


def parse_zp_html(el, barrio: str, prop_type: str) -> dict | None:
    """Fallback HTML parser para ZonaProp."""
    try:
        price_el = el.select_one("[data-price]")
        price = float(price_el["data-price"]) if price_el else 0
        title = el.get("data-title", "")
        url_el = el.select_one("a")
        url = url_el["href"] if url_el else ""
        if url and not url.startswith("http"):
            url = f"https://www.zonaprop.com.ar{url}"

        return {
            "id":           f"ZP-{el.get('data-id', '')}",
            "source":       "Zonaprop",
            "type":         prop_type,
            "barrio":       ZP_BARRIO_MAP.get(barrio, barrio),
            "address":      "",
            "title":        title,
            "description":  "",
            "m2_covered":   0,
            "m2_semi":      0,
            "m2_uncovered": 0,
            "m2_total":     0,
            "ambientes":    None,
            "price_usd":    price,
            "has_cochera":  False,
            "has_patio":    False,
            "has_terraza":  False,
            "has_balcon":   False,
            "expensas_ars": 0,
            "floor":        None,
            "url":          url,
            "image_url":    "",
            "date_created": "",
            "is_new":       False,
            "hours_ago":    9999,
            "features_raw": title,
        }
    except:
        return None


def scrape_zonaprop() -> list[dict]:
    """Scrapea ZonaProp para todos los barrios y tipos."""
    print("[ZP] Iniciando scraping...")
    results = []
    seen = set()

    for barrio in ZP_BARRIOS:
        for prop_slug, prop_type in [("ph", "PH"), ("departamentos", "Departamento")]:
            url = (
                f"https://www.zonaprop.com.ar/{prop_slug}-venta-{barrio}"
                f"-mas-de-50-m2.html?orden=fecha-bajada"
            )
            items = scrape_zonaprop_page(url, barrio, prop_type)
            for item in items:
                if item["id"] not in seen:
                    seen.add(item["id"])
                    results.append(item)
            time.sleep(2)  # Respetar rate limits

    print(f"[ZP] Total: {len(results)} propiedades")
    return results


# ══════════════════════════════════════════════
# ARGENPROP
# ══════════════════════════════════════════════

AP_BARRIOS = [
    "saavedra", "nunez", "coghlan", "belgrano",
    "colegiales", "palermo", "palermo-hollywood",
    "palermo-soho", "las-canitas",
]

AP_BARRIO_MAP = {
    "saavedra": "Saavedra",
    "nunez": "Núñez",
    "coghlan": "Coghlan",
    "belgrano": "Belgrano",
    "colegiales": "Colegiales",
    "palermo": "Palermo",
    "palermo-hollywood": "Palermo Hollywood",
    "palermo-soho": "Palermo Soho",
    "las-canitas": "Las Cañitas",
}


def scrape_argenprop_page(url: str, barrio: str, prop_type: str) -> list[dict]:
    """Scrapea una página de Argenprop."""
    try:
        resp = get(url, headers=HEADERS, timeout=15)
        resp.raise_for_status()
    except Exception as e:
        print(f"[AP] Error {url}: {e}")
        return []

    soup = BeautifulSoup(resp.text, "html.parser")
    results = []

    # Argenprop usa __NEXT_DATA__ también
    script = soup.find("script", {"id": "__NEXT_DATA__"})
    if script:
        try:
            data = json.loads(script.string)
            # Navegar la estructura de Argenprop
            props = (data.get("props", {})
                        .get("pageProps", {})
                        .get("listings", []))
            if not props:
                # Intentar otra ruta
                props = (data.get("props", {})
                            .get("pageProps", {})
                            .get("data", {})
                            .get("items", []))

            for p in props:
                parsed = parse_ap_listing(p, barrio, prop_type)
                if parsed:
                    results.append(parsed)
        except Exception as e:
            print(f"[AP] JSON parse error: {e}")

    return results


def parse_ap_listing(data: dict, barrio: str, prop_type: str) -> dict | None:
    """Parsea un listing de Argenprop."""
    try:
        # Precio
        price = float(data.get("price", {}).get("amount", 0) or 0)
        currency = data.get("price", {}).get("currency", "USD")
        if currency != "USD":
            return None

        # Superficies
        surfaces = data.get("surfaces", {})
        covered  = float(surfaces.get("roofed",     0) or 0)
        semi     = float(surfaces.get("semiRoofed", 0) or 0)
        total    = float(surfaces.get("total",      0) or 0)
        uncover  = max(0, total - covered - semi)

        title = data.get("title", "")
        desc  = data.get("description", "")
        combined = (title + " " + desc).lower()

        # Detalles
        details = {d.get("key"): d.get("value") for d in data.get("details", [])}
        rooms   = details.get("rooms") or details.get("ambientes")
        try: rooms = int(rooms) if rooms else None
        except: rooms = None

        url = data.get("url", data.get("permalink", ""))
        if url and not url.startswith("http"):
            url = f"https://www.argenprop.com{url}"

        # Foto
        photos = data.get("photos", []) or data.get("images", [])
        img = photos[0].get("url", "") if photos else ""

        pub_date_str = data.get("publicationDate", data.get("createdAt", ""))
        is_new = False; hours_ago = 9999
        if pub_date_str:
            try:
                pub_date = datetime.fromisoformat(pub_date_str.replace("Z", "+00:00"))
                delta = datetime.now(timezone.utc) - pub_date
                hours_ago = delta.total_seconds() / 3600
                is_new = hours_ago < 48
            except: pass

        return {
            "id":           f"AP-{data.get('id', '')}",
            "source":       "Argenprop",
            "type":         prop_type,
            "barrio":       AP_BARRIO_MAP.get(barrio, barrio),
            "address":      data.get("address", ""),
            "title":        title,
            "description":  desc[:500],
            "m2_covered":   covered,
            "m2_semi":      semi,
            "m2_uncovered": uncover,
            "m2_total":     total,
            "ambientes":    rooms,
            "price_usd":    price,
            "has_cochera":  "cochera" in combined or "garage" in combined,
            "has_patio":    "patio" in combined,
            "has_terraza":  "terraza" in combined,
            "has_balcon":   "balcón" in combined or "balcon" in combined,
            "expensas_ars": float(data.get("expenses", {}).get("amount", 0) or 0),
            "floor":        data.get("floor"),
            "url":          url,
            "image_url":    img,
            "date_created": pub_date_str,
            "is_new":       is_new,
            "hours_ago":    round(hours_ago, 1),
            "features_raw": combined,
        }
    except Exception as e:
        print(f"[AP] parse error: {e}")
        return None


def scrape_argenprop() -> list[dict]:
    """Scrapea Argenprop para todos los barrios y tipos."""
    print("[AP] Iniciando scraping...")
    results = []
    seen = set()

    for barrio in AP_BARRIOS:
        for prop_slug, prop_type in [("ph", "PH"), ("departamento", "Departamento")]:
            url = (
                f"https://www.argenprop.com/{prop_slug}/venta/{barrio}"
                f"?orden=fecha_desc"
            )
            items = scrape_argenprop_page(url, barrio, prop_type)
            for item in items:
                if item["id"] not in seen:
                    seen.add(item["id"])
                    results.append(item)
            time.sleep(2)

    print(f"[AP] Total: {len(results)} propiedades")
    return results
