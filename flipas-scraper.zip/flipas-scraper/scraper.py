"""
FLIPAS REAL ESTATE — Scraper principal
Orquesta todos los portales, aplica filtros y dispara notificaciones.

Uso:
    python scraper.py              → corre completo
    python scraper.py --test       → 5 propiedades fake para testear
    python scraper.py --ml-only    → solo MercadoLibre
"""

import json
import sys
import os
from datetime import datetime, timezone
from pathlib import Path

from config import DATA_JSON_PATH, SEEN_IDS_PATH, SHEETS_CONFIG
from filter_engine import filter_property
from notifications import notify_new_opportunities

sys.path.insert(0, str(Path(__file__).parent / "portals"))


def load_seen_ids() -> set:
    """Carga los IDs ya procesados para detectar oportunidades nuevas."""
    try:
        with open(SEEN_IDS_PATH) as f:
            return set(json.load(f))
    except:
        return set()


def save_seen_ids(ids: set) -> None:
    """Guarda IDs procesados. Mantiene solo los últimos 10,000."""
    ids_list = list(ids)[-10_000:]
    with open(SEEN_IDS_PATH, "w") as f:
        json.dump(ids_list, f)


def load_existing_data() -> dict:
    """Carga el data.json existente."""
    try:
        with open(DATA_JSON_PATH) as f:
            return json.load(f)
    except:
        return {"updated_at": "", "properties": []}


def save_data_json(properties: list[dict]) -> None:
    """Guarda el data.json para el dashboard."""
    output = {
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "properties": sorted(
            properties,
            key=lambda x: (
                {"urgente": 0, "oportunidad": 1, "negociable": 2}.get(x.get("alert_level"), 3),
                -x.get("score", 0),
            )
        )
    }
    with open(DATA_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2, default=str)
    print(f"[MAIN] data.json guardado: {len(properties)} oportunidades")


def push_to_sheets(new_props: list[dict]) -> None:
    """Agrega nuevas oportunidades al Google Sheet."""
    if not SHEETS_CONFIG.get("enabled") or not new_props:
        return
    try:
        import gspread
        from google.oauth2.service_account import Credentials

        scopes = ["https://www.googleapis.com/auth/spreadsheets"]
        creds = Credentials.from_service_account_file(
            SHEETS_CONFIG["credentials_file"], scopes=scopes
        )
        gc = gspread.authorize(creds)
        sh = gc.open_by_key(SHEETS_CONFIG["spreadsheet_id"])
        ws = sh.worksheet(SHEETS_CONFIG["sheet_name"])

        # Headers
        headers = [
            "Fecha detección", "ID", "Fuente", "Tipo", "Barrio", "Dirección",
            "M² cubiertos", "M² semi", "M² desc.", "M² total", "M² ponderados",
            "Ambientes", "Precio USD", "Precio efectivo", "USD/m² pond.",
            "Nivel alerta", "Score", "Cochera", "Patio", "Terraza", "Balcón",
            "Expensas ARS", "Nueva", "Horas desde publicación", "URL",
        ]
        if ws.row_count == 1 and not ws.get_all_values():
            ws.insert_row(headers, 1)

        rows = []
        for p in new_props:
            rows.append([
                datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
                p.get("id"),
                p.get("source"),
                p.get("type"),
                p.get("barrio"),
                p.get("address") or p.get("title", "")[:50],
                p.get("m2_covered", 0),
                p.get("m2_semi", 0),
                p.get("m2_uncovered", 0),
                p.get("m2_total", 0),
                p.get("m2_weighted", 0),
                p.get("ambientes", ""),
                p.get("price_usd", 0),
                p.get("effective_price", 0),
                p.get("usd_per_m2", 0),
                p.get("alert_level", "").upper(),
                p.get("score", 0),
                "Sí" if p.get("has_cochera") else "No",
                "Sí" if p.get("has_patio") else "No",
                "Sí" if p.get("has_terraza") else "No",
                "Sí" if p.get("has_balcon") else "No",
                p.get("expensas_ars", 0),
                "Sí" if p.get("is_new") else "No",
                p.get("hours_ago", ""),
                p.get("url", ""),
            ])

        if rows:
            ws.append_rows(rows, value_input_option="USER_ENTERED")
            print(f"[SHEETS] {len(rows)} filas agregadas")

    except Exception as e:
        print(f"[SHEETS] Error: {e}")


def fake_test_data() -> list[dict]:
    """Genera datos de prueba para testear el dashboard sin scrapear."""
    return [
        {
            "id": "ML-TEST-001", "source": "MercadoLibre", "type": "PH",
            "barrio": "Saavedra", "address": "Conde 3150", "title": "PH 3 amb con cochera y terraza",
            "m2_covered": 64, "m2_semi": 0, "m2_uncovered": 41,
            "m2_total": 105, "m2_weighted": 77.53, "ambientes": 3,
            "price_usd": 155000, "effective_price": 135000, "has_cochera": True,
            "has_patio": False, "has_terraza": True, "has_balcon": True,
            "usd_per_m2": 1741, "alert_level": "negociable", "score": 62,
            "expensas_ars": 0, "is_new": True, "hours_ago": 3.5,
            "url": "https://mercadolibre.com.ar",
            "image_url": "https://via.placeholder.com/300x200?text=PH+Saavedra",
            "date_created": "2026-05-28T10:00:00Z",
        },
        {
            "id": "ZP-TEST-002", "source": "Zonaprop", "type": "PH",
            "barrio": "Núñez", "address": "Av. Balbín 3200", "title": "PH 3 amb sin expensas terraza",
            "m2_covered": 64, "m2_semi": 5, "m2_uncovered": 33,
            "m2_total": 102, "m2_weighted": 74.39, "ambientes": 3,
            "price_usd": 90000, "effective_price": 90000, "has_cochera": False,
            "has_patio": False, "has_terraza": True, "has_balcon": True,
            "usd_per_m2": 1210, "alert_level": "urgente", "score": 88,
            "expensas_ars": 0, "is_new": True, "hours_ago": 1.2,
            "url": "https://zonaprop.com.ar",
            "image_url": "https://via.placeholder.com/300x200?text=PH+Nunez",
            "date_created": "2026-05-28T13:00:00Z",
        },
        {
            "id": "AP-TEST-003", "source": "Argenprop", "type": "Departamento",
            "barrio": "Palermo", "address": "Gorriti 5800", "title": "Depto 3 amb excelente estado",
            "m2_covered": 75, "m2_semi": 8, "m2_uncovered": 0,
            "m2_total": 83, "m2_weighted": 79, "ambientes": 3,
            "price_usd": 115000, "effective_price": 115000, "has_cochera": False,
            "has_patio": False, "has_terraza": False, "has_balcon": True,
            "usd_per_m2": 1456, "alert_level": "negociable", "score": 55,
            "expensas_ars": 85000, "is_new": False, "hours_ago": 26,
            "url": "https://argenprop.com",
            "image_url": "https://via.placeholder.com/300x200?text=Depto+Palermo",
            "date_created": "2026-05-27T12:00:00Z",
        },
        {
            "id": "RM-TEST-004", "source": "Remax", "type": "PH",
            "barrio": "Colegiales", "address": "Dorrego 2100", "title": "PH reciclado con patio",
            "m2_covered": 70, "m2_semi": 0, "m2_uncovered": 25,
            "m2_total": 95, "m2_weighted": 78.25, "ambientes": 3,
            "price_usd": 105000, "effective_price": 105000, "has_cochera": False,
            "has_patio": True, "has_terraza": False, "has_balcon": False,
            "usd_per_m2": 1342, "alert_level": "oportunidad", "score": 74,
            "expensas_ars": 45000, "is_new": True, "hours_ago": 8,
            "url": "https://remax.com.ar",
            "image_url": "https://via.placeholder.com/300x200?text=PH+Colegiales",
            "date_created": "2026-05-28T06:00:00Z",
        },
    ]


def run(test_mode=False, ml_only=False):
    """Función principal del scraper."""
    print(f"\n{'='*60}")
    print(f"FLIPAS SCRAPER — {datetime.now().strftime('%d/%m/%Y %H:%M')}")
    print(f"{'='*60}\n")

    seen_ids = load_seen_ids()
    all_raw = []

    if test_mode:
        print("[MAIN] MODO TEST — usando datos de ejemplo")
        all_raw = fake_test_data()
        # En modo test, todos son "nuevos"
        filtered = all_raw
        new_props = filtered
    else:
        # ── Scrapear portales ──────────────────────────────────────
        from portals.mercadolibre import scrape_mercadolibre
        ml_results = scrape_mercadolibre()
        all_raw.extend(ml_results)

        if not ml_only:
            from portals.zonaprop_argenprop import scrape_zonaprop, scrape_argenprop
            # from portals.remax import scrape_remax  # Descomentar cuando esté listo

            zp_results = scrape_zonaprop()
            all_raw.extend(zp_results)

            ap_results = scrape_argenprop()
            all_raw.extend(ap_results)

        print(f"\n[MAIN] Total crudos: {len(all_raw)} propiedades")

        # ── Filtrar ────────────────────────────────────────────────
        filtered = []
        for prop in all_raw:
            result = filter_property(prop)
            if result:
                filtered.append(result)

        print(f"[MAIN] Después de filtros: {len(filtered)} oportunidades")

        # ── Detectar nuevas ────────────────────────────────────────
        new_props = [p for p in filtered if p["id"] not in seen_ids]
        print(f"[MAIN] Nuevas (no vistas antes): {len(new_props)}")

    # ── Estadísticas ────────────────────────────────────────────
    by_level = {
        "urgente":    [p for p in filtered if p.get("alert_level") == "urgente"],
        "oportunidad":[p for p in filtered if p.get("alert_level") == "oportunidad"],
        "negociable": [p for p in filtered if p.get("alert_level") == "negociable"],
    }
    print(f"\n  🔴 Urgente:     {len(by_level['urgente'])}")
    print(f"  🟠 Oportunidad: {len(by_level['oportunidad'])}")
    print(f"  🟡 Negociable:  {len(by_level['negociable'])}")

    # ── Guardar data.json ────────────────────────────────────────
    save_data_json(filtered)

    # ── Google Sheets ────────────────────────────────────────────
    if new_props and not test_mode:
        push_to_sheets(new_props)

    # ── Notificaciones ───────────────────────────────────────────
    if new_props:
        notify_new_opportunities(new_props)

    # ── Actualizar seen IDs ──────────────────────────────────────
    if not test_mode:
        seen_ids.update(p["id"] for p in filtered)
        save_seen_ids(seen_ids)

    print(f"\n[MAIN] ✅ Completado en {datetime.now().strftime('%H:%M:%S')}\n")
    return filtered


if __name__ == "__main__":
    test_mode = "--test" in sys.argv
    ml_only   = "--ml-only" in sys.argv
    run(test_mode=test_mode, ml_only=ml_only)
